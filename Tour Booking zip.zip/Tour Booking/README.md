# Tour Booking

A simple tour booking web app with HTML, CSS, and JavaScript on the frontend, a Python backend, and MySQL for bookings.

## Project Structure

- `static/index.html` - page markup
- `static/styles.css` - responsive styling
- `static/script.js` - tour filtering, selection, totals, and booking submit
- `app.py` - Python backend and API routes
- `database/schema.sql` - MySQL tables and sample tours

Hero photo: `static/assets/travel-hero-hikers.png`, provided by the user.
Tour card photos are stored in `static/assets/tours/`. Udaipur, Uttarakhand, and Himachal Pradesh images are from Wikimedia Commons; Port Blair currently reuses the local tropical-water hero photo as a fallback because Wikimedia rate-limited the Andaman download.

## Setup

1. Create and seed the MySQL database:

   ```powershell
   mysql -u root -p < database/schema.sql
   ```

2. Copy `.env.example` to `.env`, then update your MySQL password:

   ```powershell
   Copy-Item .env.example .env
   ```

3. Install the MySQL Python driver:

   ```powershell
   python -m pip install -r requirements.txt
   ```

4. Start the backend:

   ```powershell
   python app.py
   ```

5. Open `http://127.0.0.1:8000`.

The page can show sample tours before MySQL is connected. Saving a booking requires MySQL setup.
