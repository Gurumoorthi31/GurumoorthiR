from __future__ import annotations

import json
import os
import mysql.connector
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"


FALLBACK_TOURS = [
    # ── Budget picks ──────────────────────────────────────────────────────────
    {
        "id": 3,
        "title": "Heritage City Weekend",
        "destination": "Jaipur",
        "days": 2,
        "price": 15999.00,
        "max_guests": 16,
        "description": "Forts, local markets, and a curated food crawl.",
    },
    {
        "id": 8,
        "title": "Spiritual Varanasi Sojourn",
        "destination": "Varanasi",
        "days": 3,
        "price": 18499.00,
        "max_guests": 16,
        "description": "Ganga Aarti ceremony, boat ride at dawn, temples, and silk-weaving workshops.",
    },
    {
        "id": 1,
        "title": "Coastal Sunrise Escape",
        "destination": "Goa",
        "days": 3,
        "price": 20999.00,
        "max_guests": 12,
        "description": "Beach walks, spice gardens, and a relaxed sunset cruise.",
    },
    # ── Mid-range ─────────────────────────────────────────────────────────────
    {
        "id": 2,
        "title": "Mountain Tea Trail",
        "destination": "Munnar",
        "days": 4,
        "price": 27499.00,
        "max_guests": 10,
        "description": "Tea estates, misty viewpoints, and guided nature walks.",
    },
    {
        "id": 9,
        "title": "Coorg Coffee & Jungle",
        "destination": "Coorg",
        "days": 4,
        "price": 29999.00,
        "max_guests": 12,
        "description": "Coffee plantation walks, waterfall hikes, and authentic Kodava home-stays.",
    },
    {
        "id": 4,
        "title": "Backwaters & Spice Odyssey",
        "destination": "Alleppey",
        "days": 5,
        "price": 34999.00,
        "max_guests": 8,
        "description": "Houseboat stay on tranquil backwaters, village visits, and Keralan cuisine.",
    },
    {
        "id": 6,
        "title": "Royal Rajasthan Circuit",
        "destination": "Udaipur",
        "days": 5,
        "price": 38500.00,
        "max_guests": 14,
        "description": "Palace hotels, lake sunsets, folk music, and camel rides in the desert.",
    },
    # ── Premium ───────────────────────────────────────────────────────────────
    {
        "id": 5,
        "title": "Valley of Flowers Trek",
        "destination": "Uttarakhand",
        "days": 6,
        "price": 42999.00,
        "max_guests": 10,
        "description": "UNESCO-listed alpine meadows, rare Himalayan flora, and glacier views.",
    },
    {
        "id": 10,
        "title": "Shimla & Manali Snow Trail",
        "destination": "Himachal Pradesh",
        "days": 7,
        "price": 48999.00,
        "max_guests": 14,
        "description": "Colonial Shimla, Rohtang Pass snow, Solang Valley adventure sports.",
    },
    {
        "id": 7,
        "title": "Andaman Island Retreat",
        "destination": "Port Blair",
        "days": 7,
        "price": 59999.00,
        "max_guests": 10,
        "description": "Crystal-clear waters, snorkelling at Havelock, and Cellular Jail history.",
    },
]



class DatabaseUnavailable(RuntimeError):
    pass


MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
MYSQL_USER = os.getenv("MYSQL_USER", "root")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "tour_booking")


def load_env_file() -> None:
    global MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE

    env_path = BASE_DIR / ".env"
    if env_path.exists():
        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ[key.strip()] = value.strip().strip('"').strip("'")

    MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
    MYSQL_USER = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
    MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "tour_booking")


@contextmanager
def get_connection():
    """Yield a MySQL connection with transaction management."""
    conn = None
    try:
        conn = mysql.connector.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE,
            charset="utf8mb4",
            collation="utf8mb4_general_ci",
            autocommit=False
        )
        yield conn
        conn.commit()
    except mysql.connector.Error as exc:
        if conn:
            conn.rollback()
        raise DatabaseUnavailable(f"Database error: {exc}") from exc
    except Exception:
        if conn:
            conn.rollback()
        raise
    finally:
        if conn and conn.is_connected():
            conn.close()


def split_sql_statements(schema_sql: str) -> list[str]:
    statements: list[str] = []
    current: list[str] = []
    quote: str | None = None
    escaped = False

    for char in schema_sql:
        current.append(char)

        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue

        if char in ("'", '"', "`"):
            quote = char
        elif char == ";":
            statement = "".join(current).strip().rstrip(";").strip()
            if statement:
                statements.append(statement)
            current = []

    statement = "".join(current).strip()
    if statement:
        statements.append(statement)

    return statements


def init_db() -> None:
    """Create database, tables, and seed tour data from schema.sql."""
    # Ensure the database exists
    try:
        conn = mysql.connector.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD
        )
        cursor = conn.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {MYSQL_DATABASE}")
        cursor.close()
        conn.close()
    except mysql.connector.Error as exc:
        raise DatabaseUnavailable(f"Failed to connect to MySQL to check/create database: {exc}") from exc

    schema_path = BASE_DIR / "database" / "schema.sql"
    if not schema_path.exists():
        return

    schema_sql = schema_path.read_text(encoding="utf-8")

    # Execute the schema script
    with get_connection() as conn:
        cursor = conn.cursor()
        for statement in split_sql_statements(schema_sql):
            cursor.execute(statement)
            if cursor.with_rows:
                cursor.fetchall()
        cursor.close()

    # Ensure users table exists (lightweight migration)
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id           INT AUTO_INCREMENT PRIMARY KEY,
                name         VARCHAR(120) NOT NULL,
                email        VARCHAR(160) NOT NULL UNIQUE,
                username     VARCHAR(80)  NOT NULL UNIQUE,
                password     VARCHAR(255) NOT NULL,
                created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.close()


def fetch_tours() -> list[dict[str, object]]:
    query = """
        SELECT id, title, destination, days, price, max_guests, description
        FROM   tours
        WHERE  is_active = 1
        ORDER  BY destination, title
    """
    with get_connection() as conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query)
        rows = cursor.fetchall()
        cursor.close()
    return [{k: float(v) if isinstance(v, Decimal) else v for k, v in row.items()} for row in rows]


# In-memory user store used when the database is unavailable
_MEMORY_USERS: list[dict[str, str]] = [
    {"username": "admin", "email": "admin@tourbooking.local", "name": "Admin"},
    {"username": "user",  "email": "user@tourbooking.local",  "name": "User"},
]


def register_user(payload: dict[str, object]) -> dict[str, object]:
    """Persist a new user. Raises ValueError on validation / duplicate errors."""
    name     = str(payload.get("name",     "")).strip()
    email    = str(payload.get("email",    "")).strip()
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))

    if not all([name, email, username, password]):
        raise ValueError("All fields (name, email, username, password) are required.")
    if "@" not in email or "." not in email:
        raise ValueError("Enter a valid email address.")
    if len(password) < 6:
        raise ValueError("Password must be at least 6 characters.")

    with get_connection() as conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT id FROM users WHERE username = %s OR email = %s",
            (username, email),
        )
        existing = cursor.fetchone()
        if existing:
            cursor.close()
            raise ValueError("That username or email is already taken.")

        cursor.execute(
            """
            INSERT INTO users (name, email, username, password)
            VALUES (%s, %s, %s, %s)
            """,
            (name, email, username, password),
        )
        new_id = cursor.lastrowid
        cursor.close()

    return {"id": new_id, "username": username, "name": name}


def create_booking(payload: dict[str, object]) -> dict[str, object]:
    required_fields = [
        "tour_id",
        "customer_name",
        "email",
        "phone",
        "travelers",
        "travel_date",
    ]
    missing = [field for field in required_fields if not str(payload.get(field, "")).strip()]
    if missing:
        raise ValueError(f"Missing required field: {', '.join(missing)}")

    try:
        tour_id = int(payload["tour_id"])
        travelers = int(payload["travelers"])
    except (TypeError, ValueError) as exc:
        raise ValueError("Tour and travelers must be valid numbers.") from exc

    if travelers < 1 or travelers > 30:
        raise ValueError("Travelers must be between 1 and 30.")

    try:
        selected_date = datetime.strptime(str(payload["travel_date"]), "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError("Travel date must use YYYY-MM-DD format.") from exc

    if selected_date < date.today():
        raise ValueError("Travel date cannot be in the past.")

    customer_name = str(payload["customer_name"]).strip()
    email = str(payload["email"]).strip()
    phone = str(payload["phone"]).strip()
    notes = str(payload.get("notes", "")).strip()

    if "@" not in email or "." not in email:
        raise ValueError("Enter a valid email address.")

    with get_connection() as conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, title, price FROM tours WHERE id = %s AND is_active = 1",
            (tour_id,),
        )
        tour = cursor.fetchone()
        if not tour:
            cursor.close()
            raise ValueError("Selected tour was not found.")

        total_price = float(tour["price"]) * travelers
        cursor.execute(
            """
            INSERT INTO bookings
                (tour_id, customer_name, email, phone, travelers, travel_date, notes, total_price)
            VALUES
                (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                tour_id,
                customer_name,
                email,
                phone,
                travelers,
                selected_date.isoformat(),
                notes,
                total_price,
            ),
        )
        booking_id = cursor.lastrowid
        cursor.close()

    return {
        "id": booking_id,
        "tour_title": tour["title"],
        "travelers": travelers,
        "travel_date": selected_date.isoformat(),
        "total_price": total_price,
        "status": "Pending",
    }


class TourBookingHandler(SimpleHTTPRequestHandler):
    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.end_headers()

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/health":
            self.send_json({"ok": True, "database": self.database_status()})
            return
        if path == "/api/tours":
            self.handle_tours()
            return
        if path in ("/login", "/login.html"):
            self.path = "/login.html"
        super().do_GET()


    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/bookings":
            self.handle_booking()
            return
        if path == "/api/register":
            self.handle_register()
            return
        self.send_error(HTTPStatus.NOT_FOUND, "API route not found")

    def translate_path(self, path: str) -> str:
        request_path = unquote(urlparse(path).path)
        if request_path == "/":
            target = STATIC_DIR / "index.html"
        else:
            target = STATIC_DIR / request_path.lstrip("/")

        try:
            resolved = target.resolve()
            static_root = STATIC_DIR.resolve()
            if not resolved.is_relative_to(static_root):
                return str(STATIC_DIR / "index.html")
            return str(resolved)
        except OSError:
            return str(STATIC_DIR / "index.html")

    def handle_tours(self) -> None:
        try:
            tours = fetch_tours()
            self.send_json({"databaseAvailable": True, "tours": tours})
        except DatabaseUnavailable as exc:
            self.send_json(
                {
                    "databaseAvailable": False,
                    "message": str(exc),
                    "tours": FALLBACK_TOURS,
                }
            )

    def handle_booking(self) -> None:
        try:
            payload = self.read_json_body()
            booking = create_booking(payload)
            self.send_json(
                {"message": "Booking saved successfully.", "booking": booking},
                HTTPStatus.CREATED,
            )
        except ValueError as exc:
            self.send_json({"message": str(exc)}, HTTPStatus.BAD_REQUEST)
        except DatabaseUnavailable as exc:
            self.send_json(
                {
                    "message": str(exc),
                    "setup": "Database error. Please restart the server.",
                },
                HTTPStatus.SERVICE_UNAVAILABLE,
            )

    def handle_register(self) -> None:
        try:
            payload = self.read_json_body()
            user = register_user(payload)
            self.send_json(
                {"message": "Account created successfully.", "user": user},
                HTTPStatus.CREATED,
            )
        except ValueError as exc:
            self.send_json({"message": str(exc)}, HTTPStatus.BAD_REQUEST)
        except DatabaseUnavailable:
            # DB offline – perform in-memory duplicate check then accept
            username = str(payload.get("username", "")).strip()  # type: ignore[union-attr]
            email    = str(payload.get("email",    "")).strip()
            if any(u["username"] == username or u["email"] == email for u in _MEMORY_USERS):
                self.send_json(
                    {"message": "That username or email is already taken."},
                    HTTPStatus.CONFLICT,
                )
                return
            _MEMORY_USERS.append({
                "username": username,
                "email":    email,
                "name":     str(payload.get("name", "")).strip(),
            })
            self.send_json(
                {"message": "Account created (offline mode).", "user": {"username": username}},
                HTTPStatus.CREATED,
            )

    def database_status(self) -> dict[str, object]:
        try:
            with get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchall()
                cursor.close()
            return {"available": True}
        except Exception as exc:
            return {"available": False, "message": str(exc)}

    def read_json_body(self) -> dict[str, object]:
        length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(length).decode("utf-8")
        try:
            payload = json.loads(raw_body or "{}")
        except json.JSONDecodeError as exc:
            raise ValueError("Request body must be valid JSON.") from exc
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object.")
        return payload

    def send_json(self, payload: dict[str, object], status: HTTPStatus = HTTPStatus.OK) -> None:
        body = json.dumps(payload, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def run() -> None:
    load_env_file()
    init_db()
    port = int(os.getenv("PORT", "8000"))
    server = ThreadingHTTPServer(("127.0.0.1", port), TourBookingHandler)
    print(f"Tour booking app running at http://127.0.0.1:{port}  (MySQL DB: {MYSQL_DATABASE})")
    server.serve_forever()


if __name__ == "__main__":
    run()
