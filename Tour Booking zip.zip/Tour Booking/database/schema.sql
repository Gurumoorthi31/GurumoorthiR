CREATE DATABASE IF NOT EXISTS tour_booking;
USE tour_booking;

CREATE TABLE IF NOT EXISTS tours (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  destination VARCHAR(80) NOT NULL,
  days INT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  max_guests INT NOT NULL DEFAULT 12,
  description TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_tour_title_destination (title, destination)
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tour_id INT NOT NULL,
  customer_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  travelers INT NOT NULL,
  travel_date DATE NOT NULL,
  notes TEXT,
  total_price DECIMAL(10, 2) NOT NULL,
  status ENUM('Pending', 'Confirmed', 'Cancelled') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bookings_tours
    FOREIGN KEY (tour_id) REFERENCES tours(id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);

INSERT INTO tours (title, destination, days, price, max_guests, description)
VALUES
  ('Heritage City Weekend', 'Jaipur', 2, 15999.00, 16, 'Forts, local markets, and a curated food crawl.'),
  ('Spiritual Varanasi Sojourn', 'Varanasi', 3, 18499.00, 16, 'Ganga Aarti ceremony, boat ride at dawn, temples, and silk-weaving workshops.'),
  ('Coastal Sunrise Escape', 'Goa', 3, 20999.00, 12, 'Beach walks, spice gardens, and a relaxed sunset cruise.'),
  ('Mountain Tea Trail', 'Munnar', 4, 27499.00, 10, 'Tea estates, misty viewpoints, and guided nature walks.'),
  ('Coorg Coffee & Jungle', 'Coorg', 4, 29999.00, 12, 'Coffee plantation walks, waterfall hikes, and authentic Kodava home-stays.'),
  ('Backwaters & Spice Odyssey', 'Alleppey', 5, 34999.00, 8, 'Houseboat stay on tranquil backwaters, village visits, and Keralan cuisine.'),
  ('Royal Rajasthan Circuit', 'Udaipur', 5, 38500.00, 14, 'Palace hotels, lake sunsets, folk music, and camel rides in the desert.'),
  ('Valley of Flowers Trek', 'Uttarakhand', 6, 42999.00, 10, 'UNESCO-listed alpine meadows, rare Himalayan flora, and glacier views.'),
  ('Shimla & Manali Snow Trail', 'Himachal Pradesh', 7, 48999.00, 14, 'Colonial Shimla, Rohtang Pass snow, Solang Valley adventure sports.'),
  ('Andaman Island Retreat', 'Port Blair', 7, 59999.00, 10, 'Crystal-clear waters, snorkelling at Havelock, and Cellular Jail history.')
ON DUPLICATE KEY UPDATE
  days = VALUES(days),
  price = VALUES(price),
  max_guests = VALUES(max_guests),
  description = VALUES(description),
  is_active = TRUE;
