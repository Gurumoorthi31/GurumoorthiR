Start-Transcript -Path "c:\Users\Mithran C\Documents\Tour Booking\mysql_setup.log"
Write-Host "Initializing data directory..."
& "C:\Program Files\MySQL\MySQL Server 8.4\bin\mysqld.exe" --initialize-insecure --console
Write-Host "Installing service..."
& "C:\Program Files\MySQL\MySQL Server 8.4\bin\mysqld.exe" --install MySQL84
Write-Host "Starting service..."
Start-Service MySQL84
Stop-Transcript
