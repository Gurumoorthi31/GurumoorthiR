const fallbackTours = [
  // Budget
  { id: 3,  title: "Heritage City Weekend",       destination: "Jaipur",           days: 2, price: 15999, max_guests: 16, description: "Forts, local markets, and a curated food crawl." },
  { id: 8,  title: "Spiritual Varanasi Sojourn",   destination: "Varanasi",         days: 3, price: 18499, max_guests: 16, description: "Ganga Aarti ceremony, boat ride at dawn, temples, and silk-weaving workshops." },
  { id: 1,  title: "Coastal Sunrise Escape",       destination: "Goa",              days: 3, price: 20999, max_guests: 12, description: "Beach walks, spice gardens, and a relaxed sunset cruise." },
  // Mid-range
  { id: 2,  title: "Mountain Tea Trail",           destination: "Munnar",           days: 4, price: 27499, max_guests: 10, description: "Tea estates, misty viewpoints, and guided nature walks." },
  { id: 9,  title: "Coorg Coffee & Jungle",        destination: "Coorg",            days: 4, price: 29999, max_guests: 12, description: "Coffee plantation walks, waterfall hikes, and authentic Kodava home-stays." },
  { id: 4,  title: "Backwaters & Spice Odyssey",   destination: "Alleppey",         days: 5, price: 34999, max_guests: 8,  description: "Houseboat stay on tranquil backwaters, village visits, and Keralan cuisine." },
  { id: 6,  title: "Royal Rajasthan Circuit",      destination: "Udaipur",          days: 5, price: 38500, max_guests: 14, description: "Palace hotels, lake sunsets, folk music, and camel rides in the desert." },
  // Premium
  { id: 5,  title: "Valley of Flowers Trek",       destination: "Uttarakhand",      days: 6, price: 42999, max_guests: 10, description: "UNESCO-listed alpine meadows, rare Himalayan flora, and glacier views." },
  { id: 10, title: "Shimla & Manali Snow Trail",   destination: "Himachal Pradesh", days: 7, price: 48999, max_guests: 14, description: "Colonial Shimla, Rohtang Pass snow, Solang Valley adventure sports." },
  { id: 7,  title: "Andaman Island Retreat",       destination: "Port Blair",       days: 7, price: 59999, max_guests: 10, description: "Crystal-clear waters, snorkelling at Havelock, and Cellular Jail history." }
];

const state = {
  tours: [],
  selectedTourId: null
};

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0
});

const elements = {
  tourGrid: document.querySelector("#tourGrid"),
  searchInput: document.querySelector("#searchInput"),
  destinationFilter: document.querySelector("#destinationFilter"),
  dataStatus: document.querySelector("#dataStatus"),
  tourSelect: document.querySelector("#tourSelect"),
  travelers: document.querySelector("#travelers"),
  travelDate: document.querySelector("#travelDate"),
  estimatedTotal: document.querySelector("#estimatedTotal"),
  bookingForm: document.querySelector("#bookingForm"),
  formMessage: document.querySelector("#formMessage")
};

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function getSelectedTour() {
  return state.tours.find((tour) => Number(tour.id) === Number(state.selectedTourId));
}

function setMinimumDate() {
  const today = new Date();
  const isoDate = today.toISOString().slice(0, 10);
  elements.travelDate.min = isoDate;
  elements.travelDate.value = isoDate;
}

async function loadTours() {
  try {
    const response = await fetch("/api/tours");
    if (!response.ok) {
      throw new Error("Tours could not be loaded.");
    }
    const data = await response.json();
    state.tours = data.tours.length ? data.tours : fallbackTours;
    elements.dataStatus.textContent = data.databaseAvailable
      ? ""
      : "Showing sample tours until MySQL is connected.";
  } catch (error) {
    state.tours = fallbackTours;
    elements.dataStatus.textContent = "Showing sample tours until the backend is running.";
  }

  state.selectedTourId = state.tours[0]?.id ?? null;
  renderDestinationOptions();
  renderTourOptions();
  renderTours();
  updateSummary();
}

function renderDestinationOptions() {
  const destinations = [...new Set(state.tours.map((tour) => tour.destination))].sort();
  elements.destinationFilter.innerHTML = '<option value="all">All destinations</option>';

  destinations.forEach((destination) => {
    const option = document.createElement("option");
    option.value = destination;
    option.textContent = destination;
    elements.destinationFilter.append(option);
  });
}

function renderTourOptions() {
  elements.tourSelect.innerHTML = "";

  state.tours.forEach((tour) => {
    const option = document.createElement("option");
    option.value = tour.id;
    option.textContent = `${tour.title} - ${currency.format(tour.price)}`;
    elements.tourSelect.append(option);
  });

  if (state.selectedTourId) {
    elements.tourSelect.value = state.selectedTourId;
  }
}

function getFilteredTours() {
  const searchTerm = elements.searchInput.value.trim().toLowerCase();
  const destination = elements.destinationFilter.value;

  return state.tours.filter((tour) => {
    const matchesDestination = destination === "all" || tour.destination === destination;
    const searchable = `${tour.title} ${tour.destination} ${tour.description}`.toLowerCase();
    return matchesDestination && searchable.includes(searchTerm);
  });
}

const TOUR_IMAGES = {
  Jaipur: "assets/tours/jaipur.png",
  Varanasi: "assets/tours/varanasi.png",
  Goa: "assets/tours/goa.png",
  Munnar: "assets/tours/munnar.png",
  Coorg: "assets/tours/coorg.png",
  Alleppey: "assets/tours/alleppey.png",
  Udaipur: "assets/tours/udaipur.jpg",
  Uttarakhand: "assets/tours/uttarakhand.jpg",
  "Himachal Pradesh": "assets/tours/himachal.jpg",
  "Port Blair": "assets/tours/port-blair.jpg"
};

function renderTours() {
  const filteredTours = getFilteredTours();
  elements.tourGrid.innerHTML = "";

  if (!filteredTours.length) {
    const empty = document.createElement("p");
    empty.className = "status";
    empty.textContent = "No tours match your filters.";
    elements.tourGrid.append(empty);
    return;
  }

  filteredTours.forEach((tour) => {
    const card = document.createElement("article");
    card.className = `tour-card${Number(tour.id) === Number(state.selectedTourId) ? " selected" : ""}`;
    
    const imageSrc = TOUR_IMAGES[tour.destination];
    let imageHtml = '';
    
    if (imageSrc) {
      imageHtml = `
        <div class="tour-image">
          <img src="${escapeHtml(imageSrc)}" alt="${escapeHtml(tour.title)}" loading="lazy">
        </div>
      `;
    } else {
      const gradients = [
        "linear-gradient(135deg, var(--coral), var(--sun))",
        "linear-gradient(135deg, var(--sea), var(--violet))",
        "linear-gradient(135deg, var(--violet), var(--sun))",
        "linear-gradient(135deg, var(--sea-dark), var(--coral))"
      ];
      const gradient = gradients[tour.id % gradients.length];
      imageHtml = `
        <div class="tour-image placeholder" style="background: ${gradient}">
          <span>${escapeHtml(tour.destination)}</span>
        </div>
      `;
    }

    card.innerHTML = `
      ${imageHtml}
      <div class="tour-body">
        <div>
          <h3>${escapeHtml(tour.title)}</h3>
          <p>${escapeHtml(tour.description)}</p>
        </div>
        <div class="tour-meta">
          <span>${escapeHtml(tour.destination)}</span>
          <span>${escapeHtml(tour.days)} days</span>
          <span>Up to ${escapeHtml(tour.max_guests)}</span>
        </div>
        <div class="price-row">
          <strong>${currency.format(tour.price)}</strong>
          <button class="select-tour" type="button" data-tour-id="${escapeHtml(tour.id)}">Select</button>
        </div>
      </div>
    `;
    elements.tourGrid.append(card);
  });
}

function selectTour(tourId) {
  state.selectedTourId = Number(tourId);
  elements.tourSelect.value = String(tourId);
  renderTours();
  updateSummary();
}

function updateSummary() {
  const selectedTour = getSelectedTour();
  const travelers = Math.max(Number(elements.travelers.value || 1), 1);
  const total = selectedTour ? selectedTour.price * travelers : 0;
  elements.estimatedTotal.textContent = currency.format(total);
}

async function submitBooking(event) {
  event.preventDefault();
  const submitButton = elements.bookingForm.querySelector("button[type='submit']");
  const formData = new FormData(elements.bookingForm);
  const payload = Object.fromEntries(formData.entries());
  payload.tour_id = Number(payload.tour_id);
  payload.travelers = Number(payload.travelers);

  elements.formMessage.className = "form-message";
  elements.formMessage.textContent = "Saving booking...";
  submitButton.disabled = true;

  try {
    const response = await fetch("/api/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || "Booking could not be saved.");
    }
    elements.formMessage.className = "form-message success";
    elements.formMessage.textContent = `Booking #${data.booking.id} saved for ${data.booking.tour_title}.`;
    elements.bookingForm.reset();
    setMinimumDate();
    elements.tourSelect.value = String(state.selectedTourId);
    elements.travelers.value = 2;
    updateSummary();
  } catch (error) {
    elements.formMessage.className = "form-message error";
    elements.formMessage.textContent = error.message;
  } finally {
    submitButton.disabled = false;
  }
}

elements.searchInput.addEventListener("input", renderTours);
elements.destinationFilter.addEventListener("change", renderTours);
elements.tourGrid.addEventListener("click", (event) => {
  const button = event.target.closest("[data-tour-id]");
  if (button) {
    selectTour(button.dataset.tourId);
  }
});
elements.tourSelect.addEventListener("change", (event) => selectTour(event.target.value));
elements.travelers.addEventListener("input", updateSummary);
elements.bookingForm.addEventListener("submit", submitBooking);

setMinimumDate();
loadTours();
