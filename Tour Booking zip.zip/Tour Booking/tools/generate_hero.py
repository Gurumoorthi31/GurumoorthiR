from __future__ import annotations

import math
import struct
import zlib
from pathlib import Path


WIDTH = 1200
HEIGHT = 760
OUT = Path(__file__).resolve().parents[1] / "static" / "assets" / "travel-hero.png"


def lerp(a: int, b: int, t: float) -> int:
    return round(a + (b - a) * t)


def mix(c1: tuple[int, int, int], c2: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(lerp(a, b, t) for a, b in zip(c1, c2))


pixels = bytearray(WIDTH * HEIGHT * 3)


def set_pixel(x: int, y: int, color: tuple[int, int, int]) -> None:
    if 0 <= x < WIDTH and 0 <= y < HEIGHT:
        index = (y * WIDTH + x) * 3
        pixels[index : index + 3] = bytes(color)


def fill_rect(x0: int, y0: int, x1: int, y1: int, color: tuple[int, int, int]) -> None:
    for y in range(max(0, y0), min(HEIGHT, y1)):
        for x in range(max(0, x0), min(WIDTH, x1)):
            set_pixel(x, y, color)


def fill_circle(cx: int, cy: int, radius: int, color: tuple[int, int, int]) -> None:
    r2 = radius * radius
    for y in range(cy - radius, cy + radius + 1):
        for x in range(cx - radius, cx + radius + 1):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r2:
                set_pixel(x, y, color)


def fill_triangle(
    p1: tuple[int, int],
    p2: tuple[int, int],
    p3: tuple[int, int],
    color: tuple[int, int, int],
) -> None:
    min_x = max(0, min(p1[0], p2[0], p3[0]))
    max_x = min(WIDTH - 1, max(p1[0], p2[0], p3[0]))
    min_y = max(0, min(p1[1], p2[1], p3[1]))
    max_y = min(HEIGHT - 1, max(p1[1], p2[1], p3[1]))

    def edge(a: tuple[int, int], b: tuple[int, int], p: tuple[int, int]) -> int:
        return (p[0] - a[0]) * (b[1] - a[1]) - (p[1] - a[1]) * (b[0] - a[0])

    area = edge(p1, p2, p3)
    if area == 0:
        return

    for y in range(min_y, max_y + 1):
        for x in range(min_x, max_x + 1):
            p = (x, y)
            w1 = edge(p2, p3, p)
            w2 = edge(p3, p1, p)
            w3 = edge(p1, p2, p)
            if (w1 >= 0 and w2 >= 0 and w3 >= 0) or (w1 <= 0 and w2 <= 0 and w3 <= 0):
                set_pixel(x, y, color)


def draw_line(
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    color: tuple[int, int, int],
    thickness: int = 1,
) -> None:
    steps = max(abs(x1 - x0), abs(y1 - y0), 1)
    for step in range(steps + 1):
        t = step / steps
        x = round(x0 + (x1 - x0) * t)
        y = round(y0 + (y1 - y0) * t)
        fill_circle(x, y, thickness, color)


for y in range(HEIGHT):
    t = y / HEIGHT
    if y < HEIGHT * 0.58:
        color = mix((123, 206, 225), (249, 222, 171), t / 0.58)
    elif y < HEIGHT * 0.82:
        color = mix((22, 140, 157), (5, 85, 110), (t - 0.58) / 0.24)
    else:
        color = mix((238, 202, 141), (218, 158, 88), (t - 0.82) / 0.18)
    fill_rect(0, y, WIDTH, y + 1, color)

fill_circle(930, 156, 68, (246, 168, 72))
fill_circle(930, 156, 46, (255, 205, 112))

fill_triangle((0, 446), (220, 170), (455, 446), (58, 126, 132))
fill_triangle((250, 446), (515, 205), (745, 446), (73, 147, 134))
fill_triangle((610, 446), (850, 240), (1060, 446), (47, 118, 128))
fill_triangle((130, 446), (330, 285), (525, 446), (93, 158, 122))
fill_triangle((735, 446), (990, 300), (1200, 446), (76, 143, 119))

fill_triangle((168, 245), (220, 170), (280, 246), (233, 246, 232))
fill_triangle((465, 251), (515, 205), (565, 253), (232, 246, 230))
fill_triangle((812, 274), (850, 240), (895, 277), (229, 243, 229))

for offset in range(0, 1300, 150):
    draw_line(offset - 120, 508, offset + 80, 492, (126, 210, 214), 2)
    draw_line(offset - 60, 590, offset + 150, 570, (109, 190, 199), 2)

fill_triangle((710, 566), (885, 566), (835, 615), (122, 73, 46))
fill_triangle((764, 562), (800, 447), (840, 562), (255, 246, 219))
draw_line(800, 447, 800, 566, (90, 66, 46), 2)
draw_line(735, 620, 900, 620, (255, 235, 193), 3)

draw_line(116, 660, 426, 612, (255, 246, 218), 3)
draw_line(426, 612, 640, 640, (255, 246, 218), 3)
for point in [(116, 660), (426, 612), (640, 640)]:
    fill_circle(point[0], point[1], 10, (227, 93, 69))
    fill_circle(point[0], point[1], 4, (255, 247, 225))

for x in range(0, WIDTH, 9):
    wave_y = 681 + round(math.sin(x / 38) * 5)
    set_pixel(x, wave_y, (232, 178, 104))


def write_png(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = bytearray()
    for y in range(HEIGHT):
        raw.append(0)
        start = y * WIDTH * 3
        raw.extend(pixels[start : start + WIDTH * 3])

    def chunk(kind: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + kind
            + data
            + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
        )

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", WIDTH, HEIGHT, 8, 2, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 9))
    png += chunk(b"IEND", b"")
    path.write_bytes(png)


write_png(OUT)
print(OUT)
